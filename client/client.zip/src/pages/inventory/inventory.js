import React from "react";

export default function inventory() {
  return <div>inventory</div>;
}
